<!-- Notice for idiots -->
# NOTICE:

You CANNOT deploy to Vercel, Netifly, GitHub Pages, or Cloudflare pages. They are static hosts, they just act as a web facing file system, you need the actual proxy for this to work.

<!--
                                _     _                     _       _   _          _                               _    
     /\                        | |   | |                   | |     | \ | |        | |                             | |   
    /  \     _ __ ___     ___  | |_  | |__    _   _   ___  | |_    |  \| |   ___  | |_  __      __   ___    _ __  | | __
   / /\ \   | '_ ` _ \   / _ \ | __| | '_ \  | | | | / __| | __|   | . ` |  / _ \ | __| \ \ /\ / /  / _ \  | '__| | |/ /
  / ____ \  | | | | | | |  __/ | |_  | | | | | |_| | \__ \ | |_    | |\  | |  __/ | |_   \ V  V /  | (_) | | |    |   < 
 /_/    \_\ |_| |_| |_|  \___|  \__| |_| |_|  \__, | |___/  \__|   |_| \_|  \___|  \__|   \_/\_/    \___/  |_|    |_|\_\
                                               __/ |                                                                    
                                              |___/                                                                     
-->
<!-- The font is called Big, if you are wondering -->
<div align="center">
         
<img src="https://socialify.git.ci/amethystnetwork-dev/Hypertabs/image?font=Inter&forks=1&issues=1&logo=https%3A%2F%2Fraw.githubusercontent.com%2Famethystnetwork-dev%2FHypertabs%2Fmain%2Fstatic%2Ficon.png&name=1&owner=1&pattern=Solid&stargazers=1&theme=Light" alt="Hypertabs" width="640" height="320" />

<a href="" alt="Made with NodeJS"><img src="https://img.shields.io/badge/Made%20with-Node.JS-6DA55F?style=for-the-badge&logo=node.js&logoColor=white"></a> 
<a href="https://github.com/amethystnetwork-dev/Hypertabs/graphs/contributors/" alt=""><img src="https://img.shields.io/github/contributors/amethystnetwork-dev/Hypertabs?style=for-the-badge"></a>

</div>

<div align="center">
    <h2>Get Started</h2>
    <a>To get started, press one of the buttons below to deploy Hypertabs</a>
    <br>
    <br>
    <a href="https://app.cyclic.sh/api/app/deploy/amethystnetwork-dev/Hypertabs"><img height="30px" src="https://img.shields.io/badge/cyclic-2e59c7.svg?style=for-the-badge&logo=cyclic&logoColor=white"><img></a>
    <a href="https://render.com/deploy?repo=https://github.com/amethystnetwork-dev/Hypertabs"><img height="30px" src="https://img.shields.io/badge/render-4f65f1.svg?style=for-the-badge&logo=render&logoColor=46e3b7"><img></a>
    <a href="https://amethystnetwork-dev.github.io/utils/deploy/heroku?repo=Hypertabs"><img height="30px" src="https://img.shields.io/badge/heroku-%23430098.svg?style=for-the-badge&logo=heroku&logoColor=white"><img></a>
    <a href="https://amethystnetwork-dev.github.io/docs/about-replit?repo=Hypertabs"><img height="30px" src="https://amethystnetwork-dev.github.io/assets/replit.svg"><img></a>
    <a href="https://railway.app/new/template/EBnCyy?referralCode=8zUUBB"><img height="30px" src="https://img.shields.io/badge/Railway-%234f0599.svg?style=for-the-badge&logo=railway&logoColor=white"><img></a>
</div>

## Discord Server

Press the join button to join the server:

[![Join us on Discord](https://invidget.switchblade.xyz/fzrmxgu2NR?theme=light)](https://discord.gg/fzrmxgu2NR)

## Credits

- [B3ATDROP3R](https://github.com/B3ATDROP3R)
- [Caracal.js](https://github.com/caracal-js)
- [luphoria](https://github.com/luphoria)
