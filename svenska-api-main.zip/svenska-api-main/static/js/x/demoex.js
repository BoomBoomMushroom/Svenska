Page.register({
    icon64:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAACyUlEQVR4Xu2aTYiNURjHp5mmCSOpaTSaEA1ZKF8LsRiUUpqyQMpiwm7EREnTyJ5RFppSaqyUslRKMsrCUrKShY1IRr5Cycfjdzr35s5/5n3ve2djznPfX/039z3Pc/vd+3bvOe85LS0lJSX/EzNbqK81BYjvJTfJAr3mGoRXkLvkF9mu112D8HHyxSKX9bpbkG0n1yrigdfWLLc+oovIgxr5wGkd5xJEO8kjkX9nzfDLj2QbuSfygREd6xJEr6q5xV/+bh3rDiQPqXmFSR3rDiR7yHs1rzCk492B5C21rvCb9Oh4VyC4jfwR8SovdLw7kJxU6xpu63hXILhRjYVRrXEFghNqLAxojRuQ67B/i5wstmidG5AbUNtZWKd1brDpK70slmudG5B7prazsFjrXBDELM7x69GltS5AbJOaZrBea12A2H41zaBfa12A2Ak1zeCA1roAsTNqmoHPmSBiI2qawR2tdYEVvwOmtNYFiA2qaQ59Wp88SO1TyxyGtT55kFqjljk80frkQaqVfFXTHDZoj+SxmZsfeYxpffIgNaqWOXwgS7VH0iC0VS3rcFF7JA9Sz9Uyh++kV3skDUJn1bIOE9ojaRDqJt/UMoewf+DrQSlCY2pZhynz9KgMmS6r/3RYCYcnWrVXsiAzrIYFGNc+yWJxZvhYDQtwSXslCzJ95KMaFuCC9koWi6vEsCXeKOOkXfslCSKn1K4gYW2xTPsliTU+QaryiuzSfkmCyBD5KYJFCeeJ058rILHH4kpwLny2eCd1at+kQKDXZj87WJRP5ApZrb2TAoFj5M10t4YI/y7hgzxJ1mr/JLB4hvg8eVtrNkdekhvkHDlINpMl+p7zEounSwbJQyu2y5xHWGHeJ4dJh77XvMfikvoouW7xzEHWkbsqP8hTi9/+EfO4BY/UStJPdlaym+wgq0ibji8pKSkpKSkpKcpfD60zBiqrtQkAAAAASUVORK5CYII=",
    Info: "Dark Mode extension for Hypertabs by luphoria.",
    Description:
      "This extension can toggle a dark mode on pages viewed via Hypertabs.",
    page: "demo",
    name: "Demo",
  });


class Demo {
    static async demoFunc() {

    }
}

setInfo = (parameters) => {
    // anything you want to run onload you put here


    _setInfo(parameters);
};
